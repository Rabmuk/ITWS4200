Name: Alex Kumbar

This time im remembering the readme! I really enjoyed how each page can be served by a express.get request. I created a method wrapHtml that adds the <head> to each page. This also links it to bootstrap and sets up the JUMBOTRON! Nodejs is really powerful.

Converting json to csv was interesting. There are a lot of node js libraries that helped with the process. I initially ran into problems with information being stored inside of other json arrays. I then looked into ways to flatten the json file so that information stored in arrays would instead by stored as arrayName.infoName.
And then I was told I couldn't use someone else library to do it. Using a for loop to run through the JSON file, I selected each variable and built to to a string and then appended that to a file.

I also added more buttons for viewing and downloading files.